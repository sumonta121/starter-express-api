import logo from './logo.svg';
import './App.css';
import Menu from './Menu.js';
import {BrowserRouter as Router,Routes,Link, Route } from 'react-router-dom';
import AddStudendt from './components/AddStudendt.js';
import EditStudent from './components/EditStudent.js';
import ViewStudent from './components/ViewStudent.js';

function App() {
  return (
    <>
     <Router>  
      <Menu />
        <Routes>
          <Route path='/' element={<ViewStudent />} />
          <Route path='/add-student' element={ <AddStudendt />} />
          <Route path='/edit-student/:id' element={<EditStudent />} />     
        </Routes>
     </Router>
    </>
  );
}

export default App;
